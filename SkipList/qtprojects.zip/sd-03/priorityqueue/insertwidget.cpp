#include "insertwidget.h"
#include <QString>

InsertWidget::InsertWidget(QWidget *parent) : QWidget(parent)
{
    label->setText(tr("请输入待插入元素:"));
    label->setGeometry(50, 30, 120, 30);
    lineEdit->setGeometry(50, 70, 200, 30);
    pushButton->setText(tr("确定"));
    pushButton->setGeometry(190, 120, 60, 30);

    connect(pushButton, SIGNAL(clicked()), this, SLOT(buttonClicked()));
    connect (pushButton, SIGNAL(clicked()), this, SLOT(close()));
}

InsertWidget::~InsertWidget()
{

}

void InsertWidget::buttonClicked()
{
    QString lineText = lineEdit->text();
    emit buttonSignal(lineText);
}
