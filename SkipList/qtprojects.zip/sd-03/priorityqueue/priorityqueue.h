#ifndef PRIORITYQUEUE_H
#define PRIORITYQUEUE_H
#include <iostream>
#include <string>
#include <fstream>
#define MAX_SIZE 100

using namespace std;

template <typename elementType>
class PriorityQueue
{
private:
    elementType *heap;
    size_t capacity;
    size_t size;
public:
    PriorityQueue();
    PriorityQueue(int maxElements);
    elementType * getHeap() const { return heap; };
    size_t getCapacity() const { return capacity; };
    size_t getSize() const { return size; };
    bool empty() const { return size == 0; };
    bool full() const { return capacity == size; };
    void openFile(std::string);
    void push(elementType element);
    elementType findMin() const { return heap[1]; };
    void deleteMin();
    void print() const;
    ~PriorityQueue();

    PriorityQueue<elementType> & operator+(elementType);
};

template <typename elementType>
PriorityQueue<elementType>::PriorityQueue()
{
    capacity = MAX_SIZE;
    size = 0;
    heap = new elementType[MAX_SIZE + 1];
}

template <typename elementType>
PriorityQueue<elementType>::PriorityQueue(int maxElements)
{
    int heapSize = ((maxElements + 1) < MAX_SIZE) ? (maxElements + 1) : MAX_SIZE;
    capacity = maxElements;
    size = 0;
    heap = new elementType[heapSize];
}

template <typename elementType>
void PriorityQueue<elementType>::openFile(string fileName)
{
    ifstream is(fileName);
    if (!is.is_open())
        exit(EXIT_FAILURE);
    elementType input;
    while (!is.eof())
    {
        is >> input;
        push(input);
    }
    is.close();
}

template <typename elementType>
void PriorityQueue<elementType>::push(elementType element)
{
    if (empty())
    {
        heap[0] = heap[1] = element;
        size = 1;
        return;
    }
    if (full())
        return;
    int k;
    for (k = ++size; (heap[k / 2] > element) && (k / 2 > 0); k /= 2)
        heap[k] = heap[k / 2];
    heap[k] = element;
    heap[0] = heap[1];
}

template <typename elementType>
void PriorityQueue<elementType>::deleteMin()
{
    int k, child;
    elementType lastElement;
    if (empty())
        return;
    lastElement = heap[size--];
    for (k = 1; k * 2 <= (int)size; k = child)
    {
        child = k * 2;
        if (child != (int)size && heap[child + 1] < heap[child])
            ++child;
        if (lastElement > heap[child])
            heap[k] = heap[child];
        else
            break;
    }
    heap[k] = lastElement;
}

template <typename elementType>
void PriorityQueue<elementType>::print() const
{
    for (int i = 1; i <= (int)size; i++)
        cout << heap[i] << " ";
    cout << endl;
}

template <typename elementType>
PriorityQueue<elementType>::~PriorityQueue()
{
    delete heap;
}

template <typename elementType>
PriorityQueue<elementType> & PriorityQueue<elementType>::operator+(elementType element)
{
    push(element);
    return *this;
}

#endif // PRIORITYQUEUE_H
