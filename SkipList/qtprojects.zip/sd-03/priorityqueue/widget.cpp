#include "widget.h"
#include "insertwidget.h"
#include "printwidget.h"
#include "ui_widget.h"
#include <QString>
#include <QFileDialog>
#include <QMessageBox>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

    ui->pushButtonDel->setEnabled(false);
    ui->pushButtonPrt->setEnabled(false);
    ui->pushButtonSch->setEnabled(false);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_pushButtonBrw_clicked()
{
    QString path = QFileDialog::getOpenFileName(this, tr("打开文件"), "/home", tr("Text files(*.txt)"));
    ui->lineEdit->setText(path);
    std::string fileName = path.toStdString();
    queue.openFile(fileName);
    QMessageBox::information(this, tr("提示"), tr("优先队列创建成功"));

    ui->pushButtonDel->setEnabled(true);
    ui->pushButtonPrt->setEnabled(true);
    ui->pushButtonSch->setEnabled(true);
}

void Widget::on_pushButtonSch_clicked()
{
    QString info;
    info = "优先队列中的最小元素为";
    info.append(QString::number(queue.findMin()));
    QMessageBox::information(this, tr("提示"), info);
}

void Widget::on_pushButtonDel_clicked()
{
    queue.deleteMin();
    QMessageBox::information(this, tr("提示"), tr("已删除最小元素"));
}

void Widget::on_pushButtonIns_clicked()
{
    InsertWidget *window = new InsertWidget(NULL);
    window->setWindowTitle(tr("插入元素"));
    window->setGeometry(810, 420, 300, 200);
    window->show();

    connect(window, SIGNAL(buttonSignal(QString)), this, SLOT(insert(QString)));

    ui->pushButtonDel->setEnabled(true);
    ui->pushButtonPrt->setEnabled(true);
    ui->pushButtonSch->setEnabled(true);
}

void Widget::insert(QString text)
{
    int element = text.toInt();
    queue = queue + element;
    QMessageBox::information(NULL, tr("插入结果"), tr("插入成功"));
}

void Widget::on_pushButtonPrt_clicked()
{
    QString text = "优先队列中的元素有:";
    text.append("\n");
    for (int i = 1; i < (int)queue.getSize(); i++)
    {
        text.append(QString::number(queue.getHeap()[i]));
        text.append(" ");
    }
    text.append("\n");
    PrintWidget *window = new PrintWidget(NULL);
    window->setWindowTitle(tr("打印队列"));
    window->setGeometry(810, 340, 300, 360);
    window->show();
    window->browser->append(text);
}

void Widget::on_pushButtonExt_clicked()
{
    close();
}
