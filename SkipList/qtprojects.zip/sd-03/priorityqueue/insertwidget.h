#ifndef INSERTWIDGET_H
#define INSERTWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QString>

class InsertWidget : public QWidget
{
    Q_OBJECT
public:
    explicit InsertWidget(QWidget *parent = 0);
    ~InsertWidget();

    QLabel *label = new QLabel(this);
    QLineEdit *lineEdit = new QLineEdit(this);
    QPushButton *pushButton = new QPushButton(this);
signals:
    void buttonSignal(QString);
public slots:
    void buttonClicked();
};

#endif // INSERTWIDGET_H
