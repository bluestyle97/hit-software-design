#ifndef PRINTWIDGET_H
#define PRINTWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QPushButton>
#include <QTextBrowser>
#include <QString>

class PrintWidget : public QWidget
{
    Q_OBJECT
public:
    explicit PrintWidget(QWidget *parent = 0);
    ~PrintWidget();

    QLabel *label = new QLabel(this);
    QTextBrowser *browser = new QTextBrowser(this);
    QPushButton *pushButton = new QPushButton(this);
public slots:
    void print(QString);
};

#endif // PRINTWIDGET_H
