#ifndef WIDGET_H
#define WIDGET_H

#include "priorityqueue.h"
#include <QWidget>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT
public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();
    PriorityQueue<int> queue;
private slots:
    void on_pushButtonBrw_clicked();
    void on_pushButtonSch_clicked();
    void on_pushButtonDel_clicked();
    void on_pushButtonIns_clicked();
    void on_pushButtonPrt_clicked();
    void on_pushButtonExt_clicked();
public slots:
    void insert(QString);
private:
    Ui::Widget *ui;
};

#endif // WIDGET_H
