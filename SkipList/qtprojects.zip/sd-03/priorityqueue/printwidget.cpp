#include "printwidget.h"

PrintWidget::PrintWidget(QWidget *parent) : QWidget(parent)
{
    label->setText(tr("优先队列中的元素"));
    label->setGeometry(30, 10, 100, 30);
    browser->setGeometry(30, 50, 240, 260);
    pushButton->setText(tr("确定"));
    pushButton->setGeometry(210, 320, 60, 30);

    connect(pushButton, SIGNAL(clicked()), this, SLOT(close()));
}

PrintWidget::~PrintWidget()
{

}

void PrintWidget::print(QString text)
{
    browser->append(text);
}
