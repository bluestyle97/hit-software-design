/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QLabel *label;
    QLineEdit *lineEdit;
    QPushButton *pushButtonBrw;
    QPushButton *pushButtonSch;
    QPushButton *pushButtonDel;
    QPushButton *pushButtonIns;
    QPushButton *pushButtonPrt;
    QPushButton *pushButtonExt;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QStringLiteral("Widget"));
        Widget->resize(441, 300);
        label = new QLabel(Widget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(40, 60, 61, 31));
        lineEdit = new QLineEdit(Widget);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(110, 60, 221, 31));
        pushButtonBrw = new QPushButton(Widget);
        pushButtonBrw->setObjectName(QStringLiteral("pushButtonBrw"));
        pushButtonBrw->setGeometry(QRect(340, 60, 61, 31));
        pushButtonSch = new QPushButton(Widget);
        pushButtonSch->setObjectName(QStringLiteral("pushButtonSch"));
        pushButtonSch->setGeometry(QRect(120, 170, 81, 31));
        pushButtonDel = new QPushButton(Widget);
        pushButtonDel->setObjectName(QStringLiteral("pushButtonDel"));
        pushButtonDel->setGeometry(QRect(240, 170, 81, 31));
        pushButtonIns = new QPushButton(Widget);
        pushButtonIns->setObjectName(QStringLiteral("pushButtonIns"));
        pushButtonIns->setGeometry(QRect(120, 120, 81, 31));
        pushButtonPrt = new QPushButton(Widget);
        pushButtonPrt->setObjectName(QStringLiteral("pushButtonPrt"));
        pushButtonPrt->setGeometry(QRect(240, 120, 81, 31));
        pushButtonExt = new QPushButton(Widget);
        pushButtonExt->setObjectName(QStringLiteral("pushButtonExt"));
        pushButtonExt->setGeometry(QRect(340, 220, 61, 31));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", Q_NULLPTR));
        label->setText(QApplication::translate("Widget", "\346\211\223\345\274\200\346\226\207\344\273\266\357\274\232", Q_NULLPTR));
        pushButtonBrw->setText(QApplication::translate("Widget", "\346\265\217\350\247\210", Q_NULLPTR));
        pushButtonSch->setText(QApplication::translate("Widget", "\346\220\234\347\264\242\346\234\200\345\260\217\345\205\203", Q_NULLPTR));
        pushButtonDel->setText(QApplication::translate("Widget", "\345\210\240\351\231\244\346\234\200\345\260\217\345\205\203", Q_NULLPTR));
        pushButtonIns->setText(QApplication::translate("Widget", "\346\217\222\345\205\245\345\205\203\347\264\240", Q_NULLPTR));
        pushButtonPrt->setText(QApplication::translate("Widget", "\346\211\223\345\215\260\351\230\237\345\210\227", Q_NULLPTR));
        pushButtonExt->setText(QApplication::translate("Widget", "\351\200\200\345\207\272", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
