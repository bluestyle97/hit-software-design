#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <string>
#include "skiplist.h"

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT
public:
    SkipList<int, std::string> list;

    explicit Widget(QWidget *parent = 0);
    ~Widget();
signals:
    void printSignal(QString);
private slots:
    void on_pushButtonBrowse_clicked();
    void on_pushButtonSearch_clicked();
    void on_pushButtonInsert_clicked();
    void on_pushButtonRemove_clicked();
    void on_pushButtonPrint_clicked();
    void on_pushButtonExit_clicked();
public slots:
    void search(QString);
    void insert(QString, QString);
    void remove(QString);
    void printButtonClicked();
private:
    Ui::Widget *ui;
};

#endif // WIDGET_H
