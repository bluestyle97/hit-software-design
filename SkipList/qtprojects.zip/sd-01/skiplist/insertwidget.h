#ifndef INSERTWIDGET_H
#define INSERTWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QString>

class InsertWidget : public QWidget
{
    Q_OBJECT
private:
    QLabel *labelKey = new QLabel(this);
    QLabel *labelVlaue = new QLabel(this);
    QLineEdit *editKey = new QLineEdit(this);
    QLineEdit *editValue = new QLineEdit(this);
    QPushButton *pushButton = new QPushButton(this);
public:
    explicit InsertWidget(QWidget *parent = 0);
    ~InsertWidget();
signals:
    void buttonSignal(QString, QString);
public slots:
    void buttonClicked();
};

#endif // INSERTWIDGET_H
