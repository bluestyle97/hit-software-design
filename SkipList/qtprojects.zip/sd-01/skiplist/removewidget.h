#ifndef REMOVEWIDGET_H
#define REMOVEWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QString>

class RemoveWidget : public QWidget
{
    Q_OBJECT
private:
    QLabel *label = new QLabel(this);
    QLineEdit *lineEdit = new QLineEdit(this);
    QPushButton *pushButton = new QPushButton(this);
public:
    explicit RemoveWidget(QWidget *parent = 0);
    ~RemoveWidget();
signals:
    void buttonSignal(QString);
public slots:
    void buttonClicked();
};

#endif // REMOVEWIDGET_H
