#include "widget.h"
#include "removewidget.h"
#include "searchwidget.h"
#include "insertwidget.h"
#include "printwidget.h"
#include "ui_widget.h"
#include <QString>
#include <QFileDialog>
#include <QMessageBox>
#include <string>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

    ui->pushButtonSearch->setEnabled(false);
    ui->pushButtonRemove->setEnabled(false);
    ui->pushButtonPrint->setEnabled(false);

    connect(ui->pushButtonPrint, SIGNAL(clicked()), this, SLOT(printButtonClicked()));
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_pushButtonBrowse_clicked()
{
    QString path = QFileDialog::getOpenFileName(this, tr("打开文件"), "/home", tr("Text files(*.txt)"));
    ui->lineEdit->setText(path);
    std::string filePath = path.toStdString();
    this->list.openFile(filePath);
    QMessageBox::information(this, tr("Prompt"), tr("Skiplist build successfully!"));

    ui->pushButtonSearch->setEnabled(true);     //This should be modified, pushbuttons should be enabled after the brower is clicked
    ui->pushButtonInsert->setEnabled(true);
    ui->pushButtonRemove->setEnabled(true);
    ui->pushButtonPrint->setEnabled(true);
}

void Widget::on_pushButtonSearch_clicked()
{
    SearchWidget *searchWindow = new SearchWidget(NULL);
    searchWindow->setWindowTitle(tr("查找元素"));
    searchWindow->setGeometry(810, 420, 300, 200);
    searchWindow->show();

    connect(searchWindow, SIGNAL(buttonSignal(QString)), this, SLOT(search(QString)));
}

void Widget::search(QString str)
{
    int key = str.toInt();
    std::string value = this->list.search(key);
    if (!value.empty())
    {
        QString valueStr = QString::fromStdString(value);
        QString info = "查找成功,关键字对应的值为" + valueStr;
        QMessageBox::information(NULL, tr("查找结果"), info);
    }
    else
        QMessageBox::information(NULL, tr("查找结果"), tr("查找失败,未找到关键字"));
}

void Widget::on_pushButtonInsert_clicked()
{
    InsertWidget *insertWindow = new InsertWidget(NULL);
    insertWindow->setWindowTitle(tr("插入元素"));
    insertWindow->setGeometry(710, 420, 500, 200);
    insertWindow->show();

    ui->pushButtonSearch->setEnabled(true);
    ui->pushButtonRemove->setEnabled(true);
    ui->pushButtonPrint->setEnabled(true);

    connect(insertWindow, SIGNAL(buttonSignal(QString,QString)), this, SLOT(insert(QString, QString)));
}

void Widget::insert(QString keyStr, QString valueStr)
{
    int key = keyStr.toInt();
    std::string value = valueStr.toStdString();
    if(this->list.insert(key, value))
        QMessageBox::information(NULL, tr("插入结果"), tr("插入成功"));
    else
        QMessageBox::information(NULL, tr("插入结果"), tr("插入失败"));
}

void Widget::on_pushButtonRemove_clicked()
{
   RemoveWidget *removeWindow = new RemoveWidget(NULL);
   removeWindow->setWindowTitle(tr("删除元素"));
   removeWindow->setGeometry(810, 420, 300, 200);
   removeWindow->show();

   connect(removeWindow, SIGNAL(buttonSignal(QString)), this, SLOT(remove(QString)));
}

void Widget::remove(QString str)
{
    int key = str.toInt();
    if (this->list.remove(key))
        QMessageBox::information(NULL, tr("删除结果"), tr("删除成功"));
    else
        QMessageBox::information(NULL, tr("删除结果"), tr("删除失败"));
}

void Widget::on_pushButtonPrint_clicked()
{
    PrintWidget *printWindow = new PrintWidget(NULL);
    printWindow->setWindowTitle(tr("打印跳表"));
    printWindow->setGeometry(810, 340, 300, 360);
    printWindow->show();

    connect(this, SIGNAL(printSignal(QString)), printWindow, SLOT(print(QString)));
}

void Widget::on_pushButtonExit_clicked()
{
    this->close();
}

void Widget::printButtonClicked()
{
    QString text = "";
    SkipNode<int, std::string> *pointer = this->list.getHeader()->forward[0];
    while (pointer != NULL)
    {
        text.append("key:");
        text.append(QString::number(pointer->key));
        text.append(", value:");
        text.append(QString::fromStdString(pointer->value));
        text.append(", level:");
        text.append(QString::number(pointer->level));
        text.append("\n");
        pointer = pointer->forward[0];
    }
    emit printSignal(text);
}
