#ifndef SEARCHWIDGET_H
#define SEARCHWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QString>

class SearchWidget : public QWidget
{
    Q_OBJECT
private:
    QLabel *label = new QLabel(this);
    QLineEdit *lineEdit = new QLineEdit(this);
    QPushButton *pushButton = new QPushButton(this);
public:
    explicit SearchWidget(QWidget *parent = 0);
    ~SearchWidget();
signals:
    void buttonSignal(QString);
public slots:
    void buttonClicked();
};

#endif // SEARCHWIDGET_H    Q_OBJECT
