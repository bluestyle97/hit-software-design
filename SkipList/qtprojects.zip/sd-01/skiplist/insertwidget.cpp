#include "insertwidget.h"
#include <QString>

InsertWidget::InsertWidget(QWidget *parent) : QWidget(parent)
{
    labelKey->setText(tr("请输入key:"));
    labelKey->setGeometry(50, 30, 100, 30);
    editKey->setGeometry(50, 70, 150, 30);
    labelVlaue->setText(tr("请输入value:"));
    labelVlaue->setGeometry(300, 30, 100, 30);
    editValue->setGeometry(300, 70, 150, 30);
    pushButton->setText(tr("确定"));
    pushButton->setGeometry(220, 120, 60, 30);

    connect(pushButton, SIGNAL(clicked()), this, SLOT(buttonClicked()));
    connect(pushButton, SIGNAL(clicked()), this, SLOT(close()));
}

InsertWidget::~InsertWidget()
{

}

void InsertWidget::buttonClicked()
{
    QString keyText = editKey->text();
    QString valueText = editValue->text();
    emit buttonSignal(keyText, valueText);
}
