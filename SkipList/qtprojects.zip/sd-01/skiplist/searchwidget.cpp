#include "searchwidget.h"
#include <QString>

SearchWidget::SearchWidget(QWidget *parent) : QWidget(parent)
{
    label->setText(tr("请输入关键字:"));
    label->setGeometry(50, 30, 80, 30);
    lineEdit->setGeometry(50, 70, 200, 30);
    pushButton->setText(tr("确定"));
    pushButton->setGeometry(190, 120, 60, 30);

    connect(pushButton, SIGNAL(clicked()), this, SLOT(buttonClicked()));
    connect (pushButton, SIGNAL(clicked()), this, SLOT(close()));
}

SearchWidget::~SearchWidget()
{

}

void SearchWidget::buttonClicked()
{
    QString lineText = lineEdit->text();
    emit buttonSignal(lineText);
}
