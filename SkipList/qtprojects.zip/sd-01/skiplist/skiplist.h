#ifndef SKIPLIST_H
#define SKIPLIST_H
#define MAX_LEVEL 20
#include <string>
#include <iostream>
#include <fstream>
#include <cstdlib>

template <typename keyType, typename valueType>
class SkipNode
{
public:
    keyType key;
    valueType value;
    int level;
    SkipNode<keyType, valueType> **forward;
};

template <typename keyType, typename valueType>
class SkipList
{
private:
    int level;
    SkipNode<keyType, valueType> *header;

    int randomLevel() const;
public:
    SkipList();
    bool empty() const { return header->forward[0] == NULL; };
    int getLevel() const { return level; };
    SkipNode<keyType, valueType> * getHeader() const { return header; };
    void openFile(std::string fileName);
    valueType search(keyType aKey) const;
    bool insert(keyType aKey, valueType aValue);
    bool remove(keyType aKey);
    void print() const;
    ~SkipList();
};

template <typename keyType, typename valueType>
int SkipList<keyType, valueType>::randomLevel() const
{
    int level = 1;
    while (rand() % 2)
        ++level;
    return (level < MAX_LEVEL) ? level : MAX_LEVEL;
}

template <typename keyType, typename valueType>
SkipList<keyType, valueType>::SkipList()
{
    level = 0;
    header = new SkipNode<keyType, valueType>;
    header->forward = new SkipNode<keyType, valueType> *[MAX_LEVEL];
    for (int k = 0; k < MAX_LEVEL; k++)
        header->forward[k] = NULL;
}

template <typename keyType, typename valueType>
void SkipList<keyType, valueType>::openFile(std::string fileName)
{
    std::ifstream is;
    is.open(fileName);
    if (!is.is_open())
        exit(EXIT_FAILURE);
    keyType keyInput;
    valueType valueInput;
    while (!is.eof())
    {
        is >> keyInput;
        is >> valueInput;
        this->insert(keyInput, valueInput);
    }
    is.close();
}

template <typename keyType, typename valueType>
valueType SkipList<keyType, valueType>::search(keyType aKey) const
{
    SkipNode<keyType, valueType> *pointer = header;
    SkipNode<keyType, valueType> *pointerNext = NULL;

    for (int k = level - 1; k >= 0; k--)
    {
        while ((pointerNext = pointer->forward[k]) && pointerNext->key <= aKey)
            pointer = pointerNext;
        if (pointer != header && pointer->key == aKey)
            return pointer->value;
    }
    delete pointerNext;
    delete pointer;
    return {};
}

template <typename keyType, typename valueType>
bool SkipList<keyType, valueType>::insert(keyType aKey, valueType aValue)
{
    int nodeLevel = randomLevel();
    SkipNode<keyType, valueType> *node = new SkipNode<keyType, valueType>;
    SkipNode<keyType, valueType> *pointerNext = NULL;
    SkipNode<keyType, valueType> **updates = new SkipNode<keyType, valueType> *[nodeLevel];

    node->key = aKey;
    node->value = aValue;
    node->level = nodeLevel;
    node->forward = new SkipNode<keyType, valueType> *[nodeLevel];

    for (int k = nodeLevel - 1; k >= 0; k--)
        updates[k] = header;
    for (int k = nodeLevel - 1; k >= 0; k--)
    {
        while ((pointerNext = updates[k]->forward[k]) && pointerNext->key <= aKey)
            updates[k] = pointerNext;
        if (updates[k] != header && updates[k]->key == aKey)
            return false;
    }
    for (int k = nodeLevel - 1; k >= 0; k--)
    {
        node->forward[k] = updates[k]->forward[k];
        updates[k]->forward[k] = node;
    }
    if (nodeLevel > level)
        level = nodeLevel;
    delete[] updates;
    return true;
}

template <typename keyType, typename valueType>
bool SkipList<keyType, valueType>::remove(keyType aKey)
{
    SkipNode<keyType, valueType> *pointer = header;
    SkipNode<keyType, valueType> *pointerNext = NULL;
    SkipNode<keyType, valueType> *nodePointer = NULL;
    int nodeLevel = 0;

    for (int k = level - 1; k >= 0; k--)
    {
        while ((pointerNext = pointer->forward[k]) && pointerNext->key <= aKey)
            pointer = pointerNext;
        if (pointer != header && pointer->key == aKey)
        {
            nodePointer = pointer;
            nodeLevel = k + 1;
            break;
        }
    }
    if (nodeLevel == 0)
        return false;
    for (int k = nodeLevel - 1; k >= 0; k--)
    {
        pointer = header;
        while (pointer->forward[k] != nodePointer)
            pointer = pointer->forward[k];
        pointer->forward[k] = pointer->forward[k]->forward[k];
    }
    delete nodePointer;
    if (nodeLevel == level)
        for (int k = nodeLevel - 1; k >= 0; k--)
            if (header->forward[k] != NULL)
            {
                level = k + 1;
                break;
            }
    return true;
}

template <typename keyType, typename valueType>
void SkipList<keyType, valueType>::print() const
{
    using std::cout;
    using std::endl;

    if (empty())
    {
        cout << "跳表为空" << endl;
        return;
    }
    SkipNode<keyType, valueType> *pointer = header->forward[0];
    while (pointer != NULL)
    {
        cout << "key:" << pointer->key
            << ", value:" << pointer->value
            << ", level:" << pointer->level
            << endl;
        pointer = pointer->forward[0];
    }
}

template <typename keyType, typename valueType>
SkipList<keyType, valueType>::~SkipList()
{
    delete[] header->forward;
    delete header;
}

#endif // SKIPLIST_H
