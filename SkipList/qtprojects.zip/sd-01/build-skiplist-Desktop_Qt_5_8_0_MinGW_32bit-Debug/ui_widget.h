/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QLabel *label;
    QLineEdit *lineEdit;
    QPushButton *pushButtonBrowse;
    QPushButton *pushButtonSearch;
    QPushButton *pushButtonInsert;
    QPushButton *pushButtonRemove;
    QPushButton *pushButtonPrint;
    QPushButton *pushButtonExit;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QStringLiteral("Widget"));
        Widget->resize(500, 300);
        Widget->setStyleSheet(QStringLiteral(""));
        label = new QLabel(Widget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(60, 60, 61, 31));
        lineEdit = new QLineEdit(Widget);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(120, 60, 221, 31));
        lineEdit->setStyleSheet(QStringLiteral(""));
        pushButtonBrowse = new QPushButton(Widget);
        pushButtonBrowse->setObjectName(QStringLiteral("pushButtonBrowse"));
        pushButtonBrowse->setGeometry(QRect(360, 60, 81, 31));
        pushButtonBrowse->setCursor(QCursor(Qt::ArrowCursor));
        pushButtonBrowse->setMouseTracking(false);
        pushButtonBrowse->setStyleSheet(QStringLiteral(""));
        pushButtonSearch = new QPushButton(Widget);
        pushButtonSearch->setObjectName(QStringLiteral("pushButtonSearch"));
        pushButtonSearch->setGeometry(QRect(130, 130, 81, 31));
        pushButtonInsert = new QPushButton(Widget);
        pushButtonInsert->setObjectName(QStringLiteral("pushButtonInsert"));
        pushButtonInsert->setGeometry(QRect(250, 130, 81, 31));
        pushButtonInsert->setAutoFillBackground(false);
        pushButtonInsert->setStyleSheet(QStringLiteral(""));
        pushButtonRemove = new QPushButton(Widget);
        pushButtonRemove->setObjectName(QStringLiteral("pushButtonRemove"));
        pushButtonRemove->setGeometry(QRect(130, 180, 81, 31));
        pushButtonPrint = new QPushButton(Widget);
        pushButtonPrint->setObjectName(QStringLiteral("pushButtonPrint"));
        pushButtonPrint->setGeometry(QRect(250, 180, 81, 31));
        pushButtonExit = new QPushButton(Widget);
        pushButtonExit->setObjectName(QStringLiteral("pushButtonExit"));
        pushButtonExit->setGeometry(QRect(360, 230, 81, 31));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "\350\267\263\350\241\250\347\263\273\347\273\237", Q_NULLPTR));
        label->setText(QApplication::translate("Widget", "\346\211\223\345\274\200\346\226\207\344\273\266\357\274\232", Q_NULLPTR));
        pushButtonBrowse->setText(QApplication::translate("Widget", "\346\265\217\350\247\210", Q_NULLPTR));
        pushButtonSearch->setText(QApplication::translate("Widget", "\346\237\245\346\211\276\345\205\203\347\264\240", Q_NULLPTR));
        pushButtonInsert->setText(QApplication::translate("Widget", "\346\217\222\345\205\245\345\205\203\347\264\240", Q_NULLPTR));
        pushButtonRemove->setText(QApplication::translate("Widget", "\345\210\240\351\231\244\345\205\203\347\264\240", Q_NULLPTR));
        pushButtonPrint->setText(QApplication::translate("Widget", "\346\211\223\345\215\260\350\267\263\350\241\250", Q_NULLPTR));
        pushButtonExit->setText(QApplication::translate("Widget", "\351\200\200\345\207\272", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
