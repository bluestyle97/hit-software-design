/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QLabel *label1;
    QLineEdit *lineEdit1;
    QPushButton *pushButtonOk1;
    QPushButton *pushButtonOpen;
    QPushButton *pushButtonVio;
    QPushButton *pushButtonKmp;
    QPushButton *pushButtonStl;
    QPushButton *pushButtonExit;
    QLabel *label2;
    QLineEdit *lineEdit2;
    QPushButton *pushButtonOk2;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QStringLiteral("Widget"));
        Widget->resize(431, 300);
        label1 = new QLabel(Widget);
        label1->setObjectName(QStringLiteral("label1"));
        label1->setGeometry(QRect(40, 50, 71, 31));
        lineEdit1 = new QLineEdit(Widget);
        lineEdit1->setObjectName(QStringLiteral("lineEdit1"));
        lineEdit1->setGeometry(QRect(120, 50, 191, 31));
        pushButtonOk1 = new QPushButton(Widget);
        pushButtonOk1->setObjectName(QStringLiteral("pushButtonOk1"));
        pushButtonOk1->setGeometry(QRect(330, 50, 61, 31));
        pushButtonOpen = new QPushButton(Widget);
        pushButtonOpen->setObjectName(QStringLiteral("pushButtonOpen"));
        pushButtonOpen->setGeometry(QRect(120, 150, 81, 31));
        pushButtonVio = new QPushButton(Widget);
        pushButtonVio->setObjectName(QStringLiteral("pushButtonVio"));
        pushButtonVio->setGeometry(QRect(230, 150, 81, 31));
        pushButtonKmp = new QPushButton(Widget);
        pushButtonKmp->setObjectName(QStringLiteral("pushButtonKmp"));
        pushButtonKmp->setGeometry(QRect(120, 200, 81, 31));
        pushButtonStl = new QPushButton(Widget);
        pushButtonStl->setObjectName(QStringLiteral("pushButtonStl"));
        pushButtonStl->setGeometry(QRect(230, 200, 81, 31));
        pushButtonExit = new QPushButton(Widget);
        pushButtonExit->setObjectName(QStringLiteral("pushButtonExit"));
        pushButtonExit->setGeometry(QRect(330, 230, 61, 31));
        label2 = new QLabel(Widget);
        label2->setObjectName(QStringLiteral("label2"));
        label2->setGeometry(QRect(40, 100, 81, 31));
        lineEdit2 = new QLineEdit(Widget);
        lineEdit2->setObjectName(QStringLiteral("lineEdit2"));
        lineEdit2->setGeometry(QRect(120, 100, 191, 31));
        pushButtonOk2 = new QPushButton(Widget);
        pushButtonOk2->setObjectName(QStringLiteral("pushButtonOk2"));
        pushButtonOk2->setGeometry(QRect(330, 100, 61, 31));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "\345\255\227\347\254\246\344\270\262\345\214\271\351\205\215\345\231\250", Q_NULLPTR));
        label1->setText(QApplication::translate("Widget", "\350\257\267\350\276\223\345\205\245\344\270\273\344\270\262\357\274\232", Q_NULLPTR));
        pushButtonOk1->setText(QApplication::translate("Widget", "\347\241\256\345\256\232", Q_NULLPTR));
        pushButtonOpen->setText(QApplication::translate("Widget", "\346\211\223\345\274\200\346\226\207\344\273\266", Q_NULLPTR));
        pushButtonVio->setText(QApplication::translate("Widget", "\346\232\264\345\212\233\345\214\271\351\205\215", Q_NULLPTR));
        pushButtonKmp->setText(QApplication::translate("Widget", "KMP\345\214\271\351\205\215", Q_NULLPTR));
        pushButtonStl->setText(QApplication::translate("Widget", "STL\345\214\271\351\205\215", Q_NULLPTR));
        pushButtonExit->setText(QApplication::translate("Widget", "\351\200\200\345\207\272", Q_NULLPTR));
        label2->setText(QApplication::translate("Widget", "\350\257\267\350\276\223\345\205\245\346\250\241\345\274\217\344\270\262\357\274\232", Q_NULLPTR));
        pushButtonOk2->setText(QApplication::translate("Widget", "\347\241\256\345\256\232", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
