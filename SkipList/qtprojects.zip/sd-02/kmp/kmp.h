#ifndef KMP_H
#define KMP_H
#include <string>

class String
{
private:
    void get_next(std::string, int *) const;
public:
    std::string mainString;

    String() {};
    String(std::string mstr) { mainString = mstr; };
    void open_file(std::string);
    int index(std::string) const;
    int index_kmp(std::string) const;
    ~String() {};
};

#endif // KMP_H
