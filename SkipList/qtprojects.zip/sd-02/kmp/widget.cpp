#include "widget.h"
#include "ui_widget.h"
#include <QMessageBox>
#include <QFileDialog>
#include <QString>
#include <ctime>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

    ui->pushButtonVio->setEnabled(false);
    ui->pushButtonKmp->setEnabled(false);
    ui->pushButtonStl->setEnabled(false);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_pushButtonOk1_clicked()
{
    QString lineText = ui->lineEdit1->text();
    if (lineText.isEmpty())
    {
        QMessageBox::information(this, tr("警告"), tr("主串不能为空"));
        return;
    }
    std::string textString = lineText.toStdString();
    this->main = new String(textString);
    QMessageBox::information(this, tr("提示"), tr("主串初始化成功"));
}

void Widget::on_pushButtonOk2_clicked()
{
    QString text = ui->lineEdit2->text();
    if (text.isEmpty())
    {
        QMessageBox::information(this, tr("警告"), tr("模式串不能为空"));
        return;
    }
    std::string textString = text.toStdString();
    this->patternString = textString;
    QMessageBox::information(this, tr("提示"), tr("模式串输入成功"));

    ui->pushButtonVio->setEnabled(true);
    ui->pushButtonKmp->setEnabled(true);
    ui->pushButtonStl->setEnabled(true);
}


void Widget::on_pushButtonOpen_clicked()
{
    QString path = QFileDialog::getOpenFileName(this, tr("打开文件"), "/home", tr("Text files(*.txt)"));
    std::string fileName = path.toStdString();
    this->main = new String;
    this->main->open_file(fileName);
    ui->lineEdit1->setText(QString::fromStdString(this->main->mainString));
    QMessageBox::information(this, tr("提示"), tr("主串初始化成功"));
}

void Widget::on_pushButtonVio_clicked()
{
    QString info;
    clock_t start = clock();
    int index = this->main->index(this->patternString);
    clock_t finish = clock();
    double time = 1.0 * (finish - start) / CLOCKS_PER_SEC;
    if (index >= 0)
    {
        info = "匹配成功,模式串在主串中的位置为";
        info.append(QString::number(index));
        info.append("\n");
        info.append("用时:");
        info.append(QString::number(time));
        info.append("s");
    }
    else
    {
        info = "匹配失败";
        info.append("\n");
        info.append("用时:");
        info.append(QString::number(time));
        info.append("s");
    }
    QMessageBox::information(this, tr("匹配结果"), info);
}

void Widget::on_pushButtonKmp_clicked()
{
    QString info;
    clock_t start = clock();
    int index = this->main->index_kmp(this->patternString);
    clock_t finish = clock();
    double time = 1.0 * (finish - start) / CLOCKS_PER_SEC;
    if (index >= 0)
    {
        info = "匹配成功,模式串在主串中的位置为";
        info.append(QString::number(index));
        info.append("\n");
        info.append("用时:");
        info.append(QString::number(time));
        info.append("s");
    }
    else
    {
        info = "匹配失败";
        info.append("\n");
        info.append("用时:");
        info.append(QString::number(time));
        info.append("s");
    }
    QMessageBox::information(this, tr("匹配结果"), info);
}

void Widget::on_pushButtonStl_clicked()
{
    QString info;
    clock_t start = clock();
    int index = this->main->mainString.find(this->patternString);
    clock_t finish = clock();
    double time = 1.0 * (finish - start) / CLOCKS_PER_SEC;
    if (index != (int)std::string::npos)
    {
        info = "匹配成功,模式串在主串中的位置为";
        info.append(QString::number(index));
        info.append("\n");
        info.append("用时:");
        info.append(QString::number(time));
        info.append("s");
    }
    else
    {
        info = "匹配失败";
        info.append("\n");
        info.append("用时:");
        info.append(QString::number(time));
        info.append("s");
    }
    QMessageBox::information(this, tr("匹配结果"), info);
}

void Widget::on_pushButtonExit_clicked()
{
    this->close();
}
