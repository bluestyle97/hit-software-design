#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <string>
#include "kmp.h"

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

    String *main;
    std::string patternString;

private slots:
    void on_pushButtonOk1_clicked();

    void on_pushButtonOk2_clicked();

    void on_pushButtonOpen_clicked();

    void on_pushButtonVio_clicked();

    void on_pushButtonKmp_clicked();

    void on_pushButtonStl_clicked();

    void on_pushButtonExit_clicked();

private:
    Ui::Widget *ui;
};

#endif // WIDGET_H
