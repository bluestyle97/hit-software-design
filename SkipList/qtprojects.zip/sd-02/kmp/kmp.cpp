#include "kmp.h"
#include <fstream>

void String::open_file(std::string fileName)
{
    std::ifstream is(fileName);
    if (!is.is_open())
        exit(EXIT_FAILURE);
    is >> mainString;
    is.close();
}

void String::get_next(std::string pattern, int *next) const
{
    int i = 0;
    int j = -1;
    next[0] = -1;
    while (i < (int)pattern.size() - 1)
    {
        if (j == -1 || pattern[i] == pattern[j])
            next[++i] = ++j;
        else
            j = next[j];
    }
}

int String::index(std::string pattern) const
{
    int i = 0, j = 0;
    int cursor;
    for (i = 0; i <= (int)mainString.size() - (int)pattern.size(); i++)
    {
        cursor = i;
        while (mainString[i] == pattern[j])
        {
            ++i;
            ++j;
        }
        if (j == (int)pattern.size())
            return cursor;
        i = cursor;
        j = 0;
    }
    return -1;
}

int String::index_kmp(std::string pattern) const
{
    int i = 0;
    int j = 0;
    int *next = new int[(int)pattern.size()];
    get_next(pattern, next);
    while (i < (int)mainString.size() && j < (int)pattern.size())
    {
        if (j == -1 || mainString[i] == pattern[j])
        {
            ++i;
            ++j;
        }
        else
            j = next[j];
        if (j == (int)pattern.size())
            return (i - (int)pattern.size());
    }
    return -1;
}
